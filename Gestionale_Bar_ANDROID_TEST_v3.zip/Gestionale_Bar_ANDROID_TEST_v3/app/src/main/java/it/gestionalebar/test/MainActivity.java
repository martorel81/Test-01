package it.gestionalebar.test;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends AppCompatActivity {
    private WebView webView;

    private final ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(
            new ScanContract(), result -> {
                if (result.getContents() != null) {
                    callJs("onBarcodeScanned", result.getContents());
                } else {
                    callJs("onNativeMessage", "Scansione annullata");
                }
            });

    private final ActivityResultLauncher<Void> photoLauncher = registerForActivityResult(
            new ActivityResultContracts.TakePicturePreview(), bitmap -> {
                if (bitmap == null) {
                    callJs("onNativeMessage", "Foto annullata");
                    return;
                }
                InputImage image = InputImage.fromBitmap(bitmap, 0);
                TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                recognizer.process(image)
                        .addOnSuccessListener(text -> callJs("onLabelScanned", text.getText()))
                        .addOnFailureListener(e -> callJs("onNativeMessage", "OCR non riuscito: " + e.getMessage()));
            });

    private final ActivityResultLauncher<Intent> voiceLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    ArrayList<String> values = result.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    if (values != null && !values.isEmpty()) callJs("onVoiceResult", values.get(0));
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new LocalAssetClient());
        webView.addJavascriptInterface(new Bridge(), "NativeBridge");
        webView.loadUrl("https://app.local/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private class LocalAssetClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            if (!"app.local".equals(u.getHost())) return null;
            String path = u.getPath();
            if (path == null || path.equals("/")) path = "/index.html";
            if (path.startsWith("/")) path = path.substring(1);
            try {
                InputStream in = getAssets().open(path);
                return new WebResourceResponse(mime(path), "UTF-8", in);
            } catch (Exception e) {
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", new HashMap<>(),
                        new java.io.ByteArrayInputStream("Not found".getBytes(StandardCharsets.UTF_8)));
            }
        }
    }

    private String mime(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".js")) return "application/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".svg")) return "image/svg+xml";
        return "application/octet-stream";
    }

    private void callJs(String fn, String value) {
        runOnUiThread(() -> webView.evaluateJavascript("window." + fn + " && window." + fn + "(" + JSONObject.quote(value == null ? "" : value) + ")", null));
    }

    public class Bridge {
        @JavascriptInterface
        public void scanBarcode() {
            runOnUiThread(() -> {
                ScanOptions o = new ScanOptions();
                o.setPrompt("Inquadra barcode o QR del prodotto");
                o.setBeepEnabled(true);
                o.setOrientationLocked(false);
                o.setDesiredBarcodeFormats(ScanOptions.ALL_CODE_TYPES);
                barcodeLauncher.launch(o);
            });
        }

        @JavascriptInterface
        public void scanLabel() {
            runOnUiThread(() -> photoLauncher.launch(null));
        }

        @JavascriptInterface
        public void voicePickup() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT");
                    i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Di' prodotto e quantità, es. due Coca Cola");
                    voiceLauncher.launch(i);
                } catch (Exception e) {
                    callJs("onNativeMessage", "Riconoscimento vocale non disponibile");
                }
            });
        }

        @JavascriptInterface
        public void exportExcel(String payload) {
            new Thread(() -> {
                try {
                    String location = writeWorkbook(payload);
                    callJs("onExcelExported", location);
                } catch (Exception e) {
                    callJs("onNativeMessage", "Errore Excel: " + e.getMessage());
                }
            }).start();
        }

        @JavascriptInterface
        public void toast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }
    }

    private static class Sheet {
        String name;
        List<List<Object>> rows = new ArrayList<>();
        Sheet(String n) { name = n; }
    }

    private String writeWorkbook(String payload) throws Exception {
        JSONObject root = new JSONObject(payload);
        JSONArray arr = root.getJSONArray("products");
        List<JSONObject> products = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) products.add(arr.getJSONObject(i));

        List<Sheet> sheets = new ArrayList<>();
        Sheet general = new Sheet("Generale");
        general.rows.add(headers());
        for (JSONObject p : products) general.rows.add(rowFor(p));
        sheets.add(general);

        LinkedHashMap<String, List<JSONObject>> bySupplier = new LinkedHashMap<>();
        for (JSONObject p : products) {
            double current = p.optDouble("current", 0);
            double min = p.optDouble("min", 0);
            if (current >= min) continue;
            String supplier = p.optString("supplier", "Senza fornitore").trim();
            if (supplier.isEmpty()) supplier = "Senza fornitore";
            bySupplier.computeIfAbsent(supplier, k -> new ArrayList<>()).add(p);
        }
        int idx = 1;
        Map<String, Boolean> used = new HashMap<>();
        used.put("Generale", true);
        for (Map.Entry<String, List<JSONObject>> e : bySupplier.entrySet()) {
            String n = safeSheetName(e.getKey(), used, idx++);
            Sheet sh = new Sheet(n);
            sh.rows.add(headers());
            for (JSONObject p : e.getValue()) sh.rows.add(rowFor(p));
            sheets.add(sh);
        }

        String filename = "Inventario_bar.xlsx";
        OutputStream os;
        String shownPath;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver cr = getContentResolver();
            Uri collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            String rel = Environment.DIRECTORY_DOWNLOADS + "/GestionaleBar/";
            try {
                cr.delete(collection, MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                        new String[]{filename, rel});
            } catch (Exception ignored) {}
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, rel);
            Uri uri = cr.insert(collection, cv);
            if (uri == null) throw new Exception("Impossibile creare il file nei Download");
            os = cr.openOutputStream(uri, "w");
            shownPath = "Download/GestionaleBar/" + filename;
        } else {
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "GestionaleBar");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("Impossibile creare cartella export");
            File f = new File(dir, filename);
            os = new FileOutputStream(f, false);
            shownPath = f.getAbsolutePath();
        }
        if (os == null) throw new Exception("Impossibile aprire il file Excel");
        try (ZipOutputStream zip = new ZipOutputStream(os)) {
            put(zip, "[Content_Types].xml", contentTypes(sheets.size()));
            put(zip, "_rels/.rels", relsRoot());
            put(zip, "xl/workbook.xml", workbookXml(sheets));
            put(zip, "xl/_rels/workbook.xml.rels", workbookRels(sheets.size()));
            put(zip, "xl/styles.xml", stylesXml());
            for (int i = 0; i < sheets.size(); i++) put(zip, "xl/worksheets/sheet" + (i + 1) + ".xml", sheetXml(sheets.get(i)));
        }
        return shownPath;
    }

    private List<Object> headers() {
        List<Object> r = new ArrayList<>();
        String[] h = {"Prodotto","Categoria","Fornitore","Giacenza","Unita","Minimo","Obiettivo","Stato","Da ordinare","Barcode/QR","Scadenza","Posizione"};
        java.util.Collections.addAll(r, h);
        return r;
    }

    private List<Object> rowFor(JSONObject p) {
        List<Object> r = new ArrayList<>();
        double cur = p.optDouble("current",0), min = p.optDouble("min",0), target = p.optDouble("target",0), step = p.optDouble("step",1);
        if (step <= 0) step = 1;
        double order = cur < min ? Math.ceil(((Math.max(0,target-cur))/step)-1e-9)*step : 0;
        r.add(p.optString("name","")); r.add(p.optString("category","")); r.add(p.optString("supplier",""));
        r.add(cur); r.add(p.optString("unit","")); r.add(min); r.add(target); r.add(cur < min ? "MANCANTE" : "OK"); r.add(order);
        r.add(p.optString("code","")); r.add(p.optString("expiry","")); r.add(p.optString("location",""));
        return r;
    }

    private String safeSheetName(String input, Map<String, Boolean> used, int suffix) {
        String n = input.replaceAll("[\\\\/*?:\\[\\]]", " ").trim();
        if (n.isEmpty()) n = "Fornitore " + suffix;
        if (n.length() > 31) n = n.substring(0,31);
        String base = n; int x=2;
        while (used.containsKey(n)) {
            String s = " (" + x++ + ")";
            n = base.substring(0, Math.min(base.length(), 31-s.length())) + s;
        }
        used.put(n,true); return n;
    }

    private void put(ZipOutputStream zip, String name, String text) throws Exception {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(text.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private String contentTypes(int count) {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        for(int i=1;i<=count;i++) s.append("<Override PartName=\"/xl/worksheets/sheet").append(i).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
        return s.append("</Types>").toString();
    }
    private String relsRoot() { return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"; }
    private String workbookXml(List<Sheet> sheets) {
        StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
        for(int i=0;i<sheets.size();i++) s.append("<sheet name=\"").append(xml(sheets.get(i).name)).append("\" sheetId=\"").append(i+1).append("\" r:id=\"rId").append(i+1).append("\"/>");
        return s.append("</sheets></workbook>").toString();
    }
    private String workbookRels(int count) {
        StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for(int i=1;i<=count;i++) s.append("<Relationship Id=\"rId").append(i).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").append(i).append(".xml\"/>");
        s.append("<Relationship Id=\"rId").append(count+1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
        return s.toString();
    }
    private String stylesXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts><fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFF4B942\"/><bgColor indexed=\"64\"/></patternFill></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\"/></cellXfs></styleSheet>";
    }
    private String sheetXml(Sheet sheet) {
        StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><cols>");
        int[] widths={30,16,24,12,12,10,10,13,13,22,14,18};
        for(int i=0;i<widths.length;i++) s.append("<col min=\"").append(i+1).append("\" max=\"").append(i+1).append("\" width=\"").append(widths[i]).append("\" customWidth=\"1\"/>");
        s.append("</cols><sheetData>");
        for(int r=0;r<sheet.rows.size();r++) {
            s.append("<row r=\"").append(r+1).append("\">");
            List<Object> row=sheet.rows.get(r);
            for(int c=0;c<row.size();c++) {
                Object v=row.get(c); String ref=colName(c+1)+(r+1);
                if(v instanceof Number) s.append("<c r=\"").append(ref).append("\" t=\"n\"").append(r==0?" s=\"1\"":"").append("><v>").append(v).append("</v></c>");
                else s.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"").append(r==0?" s=\"1\"":"").append("><is><t>").append(xml(String.valueOf(v))).append("</t></is></c>");
            }
            s.append("</row>");
        }
        return s.append("</sheetData><autoFilter ref=\"A1:L").append(Math.max(1,sheet.rows.size())).append("\"/></worksheet>").toString();
    }
    private String colName(int n){ StringBuilder s=new StringBuilder(); while(n>0){n--;s.insert(0,(char)('A'+(n%26)));n/=26;}return s.toString(); }
    private String xml(String v){ return v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;"); }
}

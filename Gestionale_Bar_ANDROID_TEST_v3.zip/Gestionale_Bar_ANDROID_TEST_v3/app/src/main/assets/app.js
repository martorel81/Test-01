const KEY='gestionale_bar_android_test_v3';
const HIST='gestionale_bar_history_v3';
const demo=[
 {id:1,name:'Coca-Cola 33 cl',category:'Bibite',supplier:'Bibite SRL',unit:'cartone',current:3,min:2,target:5,step:1,code:'8000000000011',expiry:'2027-03-30',location:'Magazzino bibite'},
 {id:2,name:'Acqua naturale 0,5',category:'Bibite',supplier:'Bibite SRL',unit:'confezione',current:2,min:3,target:8,step:1,code:'8000000000028',expiry:'2027-05-10',location:'Magazzino bibite'},
 {id:3,name:'Sciroppo menta',category:'Sciroppi',supplier:'Rossi Bevande',unit:'bottiglia',current:4,min:3,target:6,step:.25,code:'8000000000035',expiry:'2027-01-15',location:'Retrobanco'},
 {id:4,name:'Sciroppo granatina',category:'Sciroppi',supplier:'Rossi Bevande',unit:'bottiglia',current:1.5,min:2,target:5,step:.25,code:'8000000000042',expiry:'2026-11-02',location:'Retrobanco'},
 {id:5,name:'Patatine classiche',category:'Snack',supplier:'Dolci & Snack',unit:'cartone',current:0,min:1,target:3,step:1,code:'8000000000059',expiry:'2026-10-20',location:'Scaffale snack'},
 {id:6,name:'Croissant cioccolato',category:'Dolci',supplier:'Dolci & Snack',unit:'confezione',current:2,min:2,target:4,step:1,code:'8000000000066',expiry:'2026-10-16',location:'Scaffale dolci'}
];
let products=loadProducts();
let history=JSON.parse(localStorage.getItem(HIST)||'[]');
let currentProductId=null, editingId=null, scanCategory='Tutte', inventoryCategory='Tutte', scanTarget='lookup';
let voiceCandidate=null;

function loadProducts(){
 const raw=JSON.parse(localStorage.getItem(KEY)||'null');
 return Array.isArray(raw)&&raw.length?raw:demo.map(x=>({...x}));
}
function persist(){localStorage.setItem(KEY,JSON.stringify(products));localStorage.setItem(HIST,JSON.stringify(history));}
function save(){persist();renderAll()}
function fmt(n){n=Number(n)||0;return Number.isInteger(n)?String(n):String(Math.round(n*100)/100).replace('.',',')}
function esc(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function norm(s){return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim()}
function isLow(p){return Number(p.current)<Number(p.min)}
function orderQty(p){if(!isLow(p))return 0;const step=Number(p.step)||1;return Math.round(Math.ceil((Math.max(0,Number(p.target)-Number(p.current))/step)-1e-9)*step*100)/100}
function categories(){return ['Tutte',...Array.from(new Set(products.map(p=>p.category||'Altro'))).sort((a,b)=>a.localeCompare(b))]}
function productById(id){return products.find(p=>Number(p.id)===Number(id))}
function toast(t){const e=document.getElementById('toast');e.textContent=t;e.style.display='block';clearTimeout(window._tt);window._tt=setTimeout(()=>e.style.display='none',1800)}
function nativeMessage(t){toast(t)}
window.onNativeMessage=nativeMessage;

function showPage(id){
 document.querySelectorAll('.page').forEach(x=>x.classList.toggle('active',x.id===id));
 document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.page===id));
 renderAll();window.scrollTo(0,0);
}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));

function logChange(p,oldV,newV,reason){
 history.unshift({ts:new Date().toISOString(),product:p.name,old:Number(oldV),next:Number(newV),reason});
 history=history.slice(0,300);
}

function renderHome(){
 const low=products.filter(isLow), suppliers=[...new Set(low.map(p=>p.supplier))];
 document.getElementById('statProducts').textContent=products.length;
 document.getElementById('statLow').textContent=low.length;
 document.getElementById('statSuppliers').textContent=suppliers.length;
 document.getElementById('homeLow').innerHTML=low.length?low.map(p=>`<div class="row" onclick="openProduct(${p.id})"><div><b>${esc(p.name)}</b><br><small>${esc(p.supplier)} · ${esc(p.category)}</small></div><div class="right"><span class="pill bad">${fmt(p.current)} ${esc(p.unit)}</span><br><small>ordina ${fmt(orderQty(p))}</small></div></div>`).join(''):'<div class="empty">Nessun prodotto sotto scorta.</div>';
}

function categoryButtons(target,selected,handler){
 document.getElementById(target).innerHTML=categories().map(c=>`<button class="btn ${c===selected?'selected':''}" onclick="${handler}('${esc(c)}')">${esc(c)}</button>`).join('');
}
function setScanCategory(c){scanCategory=c;renderScan()}
function setInventoryCategory(c){inventoryCategory=c;renderInventory()}
function renderScan(){categoryButtons('scanCategories',scanCategory,'setScanCategory')}

function renderInventory(){
 categoryButtons('inventoryCategories',inventoryCategory,'setInventoryCategory');
 const q=norm(document.getElementById('inventorySearch')?.value||'');
 const list=products.filter(p=>(inventoryCategory==='Tutte'||p.category===inventoryCategory)&&(!q||norm(`${p.name} ${p.supplier} ${p.category}`).includes(q)));
 document.getElementById('inventoryList').innerHTML=list.length?list.map(p=>`<div class="product">
   <div class="row"><div><h3>${esc(p.name)}</h3><small>${esc(p.supplier)} · ${esc(p.category)}</small></div><span class="pill ${isLow(p)?'bad':'ok'}">${isLow(p)?'MANCANTE':'OK'}</span></div>
   <small>Min ${fmt(p.min)} · Obiettivo ${fmt(p.target)} · ${esc(p.unit)}</small>
   <div class="qty"><button class="btn" onclick="bumpInventory(${p.id},-1)">−</button><input id="iq${p.id}" type="number" min="0" step="${p.step}" value="${p.current}" oninput="previewInventory(${p.id})"><button class="btn" onclick="bumpInventory(${p.id},1)">+</button></div>
   <div id="ip${p.id}" class="status-banner ${isLow(p)?'bad':'ok'}">${isLow(p)?'MANCANTE · da ordinare '+fmt(orderQty(p)):'OK · scorta sufficiente'}</div>
   <button class="btn wide" onclick="saveInventory(${p.id})">SALVA GIACENZA</button>
 </div>`).join(''):'<div class="panel empty">Nessun prodotto trovato.</div>';
}
function bumpInventory(id,dir){const p=productById(id),e=document.getElementById('iq'+id);e.value=Math.max(0,Math.round((Number(e.value||0)+dir*(Number(p.step)||1))*100)/100);previewInventory(id)}
function previewInventory(id){const p=productById(id),v=Number(document.getElementById('iq'+id).value||0),e=document.getElementById('ip'+id);const low=v<Number(p.min);e.className='status-banner '+(low?'bad':'ok');const oq=low?Math.max(0,Number(p.target)-v):0;e.textContent=low?'MANCANTE · circa '+fmt(oq)+' '+p.unit+' per arrivare all’obiettivo':'OK · scorta sufficiente'}
function saveInventory(id){const p=productById(id),old=p.current;p.current=Math.max(0,Number(document.getElementById('iq'+id).value||0));logChange(p,old,p.current,'Inventario');save();toast('Giacenza aggiornata')}
function finishInventory(){exportExcel();toast('Inventario salvato · preparo Excel')}

function renderProducts(){
 const q=norm(document.getElementById('productSearch')?.value||'');
 const list=products.filter(p=>!q||norm(`${p.name} ${p.supplier} ${p.category} ${p.code}`).includes(q));
 document.getElementById('productList').innerHTML=list.map(p=>`<div class="product" onclick="openProduct(${p.id})"><div class="row"><div><b>${esc(p.name)}</b><br><small>${esc(p.supplier)} · ${esc(p.category)}</small></div><span class="pill ${isLow(p)?'bad':'ok'}">${fmt(p.current)} ${esc(p.unit)}</span></div><small>Min ${fmt(p.min)} · Obj ${fmt(p.target)}${p.code?' · '+esc(p.code):''}${p.expiry?' · scad. '+esc(p.expiry):''}</small></div>`).join('');
}
function addProduct(){
 const name=document.getElementById('pName').value.trim(),supplier=document.getElementById('pSupplier').value.trim();
 if(!name||!supplier){toast('Inserisci almeno nome e fornitore');return}
 const code=document.getElementById('pCode').value.trim();
 if(code&&products.some(p=>p.code===code)){toast('Questo barcode è già assegnato');return}
 const p={id:Date.now(),name,category:document.getElementById('pCategory').value||'Altro',supplier,unit:document.getElementById('pUnit').value,current:Number(document.getElementById('pCurrent').value)||0,min:Number(document.getElementById('pMin').value)||0,target:Number(document.getElementById('pTarget').value)||0,step:Number(document.getElementById('pStep').value)||1,code,expiry:document.getElementById('pExpiry').value,location:document.getElementById('pLocation').value.trim()};
 products.push(p);history.unshift({ts:new Date().toISOString(),product:p.name,old:0,next:p.current,reason:'Nuovo prodotto'});
 ['pName','pSupplier','pCode','pExpiry','pLocation'].forEach(id=>document.getElementById(id).value='');save();toast('Prodotto aggiunto')
}
function startCodeForNew(){scanTarget='new';NativeBridge.scanBarcode()}

function openProduct(id){
 const p=productById(id);if(!p)return;currentProductId=p.id;
 document.getElementById('mName').textContent=p.name;
 document.getElementById('mMeta').textContent=`${p.category} · ${p.supplier} · ${p.unit}${p.code?' · '+p.code:''}`;
 document.getElementById('mQty').value=p.current;document.getElementById('mQty').step=p.step||1;
 document.getElementById('mMin').value=p.min;document.getElementById('mTarget').value=p.target;document.getElementById('mExpiry').value=p.expiry||'';document.getElementById('mLocation').value=p.location||'';
 renderModalStatus();document.getElementById('productModal').classList.remove('hidden');
}
function closeProductModal(){document.getElementById('productModal').classList.add('hidden')}
function modalBump(dir){const p=productById(currentProductId),e=document.getElementById('mQty');e.value=Math.max(0,Math.round((Number(e.value||0)+dir*(Number(p.step)||1))*100)/100);renderModalStatus()}
function renderModalStatus(){const p=productById(currentProductId);if(!p)return;const cur=Number(document.getElementById('mQty').value||0),min=Number(document.getElementById('mMin').value||0),target=Number(document.getElementById('mTarget').value||0);const low=cur<min,e=document.getElementById('mStatus');e.className='status-banner '+(low?'bad':'ok');e.textContent=low?`MANCANTE · giacenza ${fmt(cur)}, minimo ${fmt(min)}, per obiettivo mancano ${fmt(Math.max(0,target-cur))}`:`OK · giacenza ${fmt(cur)}, minimo ${fmt(min)}`}
function saveModal(){const p=productById(currentProductId);if(!p)return;const old=p.current;p.current=Math.max(0,Number(document.getElementById('mQty').value||0));p.min=Math.max(0,Number(document.getElementById('mMin').value||0));p.target=Math.max(0,Number(document.getElementById('mTarget').value||0));p.expiry=document.getElementById('mExpiry').value;p.location=document.getElementById('mLocation').value.trim();if(old!==p.current)logChange(p,old,p.current,'Scheda prodotto');save();renderModalStatus();toast(isLow(p)?'Salvato · prodotto ancora mancante':'Salvato · prodotto OK')}
function editModalProduct(){editingId=currentProductId;closeProductModal();openEdit(editingId)}
function openEdit(id){const p=productById(id);if(!p)return;editingId=id;['Name','Category','Supplier','Unit','Code','Step','Min','Target','Expiry','Location'].forEach(k=>{const map={Name:'name',Category:'category',Supplier:'supplier',Unit:'unit',Code:'code',Step:'step',Min:'min',Target:'target',Expiry:'expiry',Location:'location'};document.getElementById('e'+k).value=p[map[k]]??''});document.getElementById('editModal').classList.remove('hidden')}
function closeEditModal(){document.getElementById('editModal').classList.add('hidden')}
function saveEdit(){const p=productById(editingId);if(!p)return;const code=document.getElementById('eCode').value.trim();if(code&&products.some(x=>x.id!==p.id&&x.code===code)){toast('Barcode già usato');return}p.name=document.getElementById('eName').value.trim();p.category=document.getElementById('eCategory').value.trim()||'Altro';p.supplier=document.getElementById('eSupplier').value.trim();p.unit=document.getElementById('eUnit').value.trim();p.code=code;p.step=Number(document.getElementById('eStep').value)||1;p.min=Number(document.getElementById('eMin').value)||0;p.target=Number(document.getElementById('eTarget').value)||0;p.expiry=document.getElementById('eExpiry').value;p.location=document.getElementById('eLocation').value.trim();save();closeEditModal();toast('Modifiche salvate')}
function deleteEditing(){const p=productById(editingId);if(!p||!confirm('Eliminare '+p.name+'?'))return;products=products.filter(x=>x.id!==p.id);save();closeEditModal();toast('Prodotto eliminato')}

window.onBarcodeScanned=function(raw){
 const code=String(raw||'').trim();if(!code)return;
 document.getElementById('scanLog').textContent='Codice letto: '+code;
 if(scanTarget==='new'){document.getElementById('pCode').value=code;scanTarget='lookup';showPage('products');toast('Codice inserito nel nuovo prodotto');return}
 const p=products.find(x=>String(x.code||'').trim()===code);
 if(p){openProduct(p.id);toast('Prodotto riconosciuto: '+p.name);return}
 document.getElementById('pCode').value=code;if(scanCategory!=='Tutte')document.getElementById('pCategory').value=scanCategory;showPage('products');toast('Prodotto non registrato: completa la scheda')
};
function scoreLabel(p,text){const t=norm(text),n=norm(p.name);if(!t||!n)return 0;if(t.includes(n))return 2;const tokens=n.split(' ').filter(x=>x.length>2);if(!tokens.length)return 0;const hits=tokens.filter(x=>t.includes(x)).length;return hits/tokens.length}
window.onLabelScanned=function(text){
 const clean=String(text||'').trim();document.getElementById('scanLog').textContent=clean?('Testo etichetta:\n'+clean):'Nessun testo riconosciuto';
 const pool=products.filter(p=>scanCategory==='Tutte'||p.category===scanCategory);let best=null,bestScore=0;pool.forEach(p=>{const s=scoreLabel(p,clean);if(s>bestScore){best=p;bestScore=s}});
 if(best&&bestScore>=.45){openProduct(best.id);toast('Etichetta associata a '+best.name+' ('+Math.round(Math.min(1,bestScore)*100)+'%)')}
 else {showPage('products');if(scanCategory!=='Tutte')document.getElementById('pCategory').value=scanCategory;const first=clean.split('\n').map(x=>x.trim()).find(x=>x.length>2);if(first)document.getElementById('pName').value=first.slice(0,70);toast('Nessuna corrispondenza sicura: completa il nuovo prodotto')}
};

function renderOrders(){
 const groups={};products.filter(isLow).forEach(p=>(groups[p.supplier]??=[]).push(p));const names=Object.keys(groups).sort();window._orders=groups;
 document.getElementById('ordersList').innerHTML=names.length?names.map(s=>`<div class="panel"><div class="order-head"><h2>${esc(s)}</h2><button class="btn order-copy" onclick="copyOrder('${encodeURIComponent(s)}')">GENERA LISTA</button></div>${groups[s].map(p=>`<div class="row"><div><b>${esc(p.name)}</b><br><small>Giacenza ${fmt(p.current)} · min ${fmt(p.min)} · obiettivo ${fmt(p.target)}</small></div><div class="right"><b>${fmt(orderQty(p))} ${esc(p.unit)}</b></div></div>`).join('')}</div>`).join(''):'<div class="panel empty">Tutto a posto: nessun ordine necessario.</div>';
}
function copyOrder(enc){const s=decodeURIComponent(enc),arr=window._orders[s]||[];const txt=['ORDINE '+s,'',...arr.map(p=>`${fmt(orderQty(p))} ${p.unit} - ${p.name}`)].join('\n');navigator.clipboard?.writeText(txt).then(()=>toast('Lista ordine copiata')).catch(()=>{document.getElementById('scanLog').textContent=txt;toast('Lista generata')})}

function daysTo(date){if(!date)return 99999;const d=new Date(date+'T12:00:00'),now=new Date();now.setHours(12,0,0,0);return Math.ceil((d-now)/86400000)}
function renderExpiries(){const list=products.filter(p=>p.expiry).sort((a,b)=>a.expiry.localeCompare(b.expiry));document.getElementById('expiryList').innerHTML=list.length?list.map(p=>{const d=daysTo(p.expiry),cls=d<0?'expiry-late':d<=7?'expiry-soon':'',label=d<0?`SCADUTO ${Math.abs(d)}g fa`:d===0?'SCADE OGGI':d<=30?`tra ${d} giorni`:p.expiry;return `<div class="product ${cls}" onclick="openProduct(${p.id})"><div class="row"><div><b>${esc(p.name)}</b><br><small>${esc(p.category)} · ${fmt(p.current)} ${esc(p.unit)}</small></div><span class="pill ${d<0?'bad':d<=7?'warn':'ok'}">${esc(label)}</span></div><small>Scadenza ${esc(p.expiry)}</small></div>`}).join(''):'<div class="panel empty">Nessuna scadenza registrata.</div>'}

function renderHistory(){document.getElementById('historyList').innerHTML=history.length?history.slice(0,100).map(h=>`<div class="panel history-item"><b>${esc(h.product)}</b><span>${new Date(h.ts).toLocaleString('it-IT')} · ${esc(h.reason)} · ${fmt(h.old)} → ${fmt(h.next)}</span></div>`).join(''):'<div class="panel empty">Storico vuoto.</div>'}
function clearHistory(){if(confirm('Svuotare lo storico?')){history=[];save();toast('Storico svuotato')}}

function wordQty(t){const m=norm(t).match(/^([0-9]+(?:[.,][0-9]+)?|un|uno|una|due|tre|quattro|cinque|sei|sette|otto|nove|dieci)\b/);if(!m)return {qty:1,rest:norm(t)};const map={un:1,uno:1,una:1,due:2,tre:3,quattro:4,cinque:5,sei:6,sette:7,otto:8,nove:9,dieci:10};const qty=map[m[1]]??Number(m[1].replace(',','.'));return {qty:qty||1,rest:norm(t).slice(m[0].length).trim()}}
function voiceScore(p,q){const n=norm(p.name);if(!q)return 0;if(n.includes(q)||q.includes(n))return 2;const toks=q.split(' ').filter(x=>x.length>2);if(!toks.length)return 0;return toks.filter(x=>n.includes(x)).length/toks.length}
window.onVoiceResult=function(text){document.getElementById('voiceLog').textContent='Hai detto: '+text;const x=wordQty(text);let best=null,score=0;products.forEach(p=>{const s=voiceScore(p,x.rest);if(s>score){best=p;score=s}});if(best&&score>=.45){voiceCandidate={id:best.id,qty:x.qty};document.getElementById('voiceConfirm').innerHTML=`<hr><p><b>${fmt(x.qty)} × ${esc(best.name)}</b></p><p class="muted">Giacenza attuale ${fmt(best.current)} ${esc(best.unit)} → dopo il prelievo ${fmt(Math.max(0,best.current-x.qty))}</p><button class="btn primary wide" onclick="confirmVoice()">CONFERMA PRELIEVO</button>`}else{voiceCandidate=null;document.getElementById('voiceConfirm').innerHTML='<p class="muted">Non ho trovato un prodotto con sufficiente sicurezza. Riprova pronunciando il nome come è registrato.</p>'}}
function confirmVoice(){if(!voiceCandidate)return;const p=productById(voiceCandidate.id),old=p.current;p.current=Math.max(0,Math.round((Number(p.current)-Number(voiceCandidate.qty))*100)/100);logChange(p,old,p.current,'Prelievo vocale');voiceCandidate=null;document.getElementById('voiceConfirm').innerHTML='';save();document.getElementById('voiceLog').textContent=`Registrato: ${p.name} · nuova giacenza ${fmt(p.current)} ${p.unit}`;toast(isLow(p)?'Prelievo registrato · ora è MANCANTE':'Prelievo registrato')}

function exportExcel(){const payload=JSON.stringify({generatedAt:new Date().toISOString(),products});NativeBridge.exportExcel(payload)}
window.onExcelExported=function(path){toast('Excel aggiornato');document.getElementById('scanLog').textContent='Excel salvato in: '+path}

function renderAll(){renderHome();renderScan();renderInventory();renderProducts();renderOrders();renderExpiries();renderHistory()}

if(!window.NativeBridge){
 window.NativeBridge={scanBarcode(){const x=prompt('Codice barcode/QR di test:');if(x)onBarcodeScanned(x)},scanLabel(){const x=prompt('Testo etichetta OCR di test:');if(x)onLabelScanned(x)},voicePickup(){const x=prompt('Frase vocale di test:');if(x)onVoiceResult(x)},exportExcel(){toast('Export Excel disponibile nell’app Android compilata')},toast};
}
renderAll();

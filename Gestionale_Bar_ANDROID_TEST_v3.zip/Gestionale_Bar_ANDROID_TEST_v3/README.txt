GESTIONALE BAR - ANDROID TEST v0.3
=================================

OBIETTIVO
---------
Questa e' la versione di prova Android autonoma del Gestionale Bar.
Non usa Termux, Flask o Chrome durante l'uso dell'app installata.

FUNZIONI INCLUSE
----------------
- Home con prodotti mancanti e riepilogo.
- Inventario con aggiornamento immediato OK / MANCANTE.
- Scanner nativo barcode e QR.
- Selezione categoria prima della scansione/riconoscimento.
- Foto etichetta + OCR per tentare il riconoscimento del prodotto.
- Se il codice e' conosciuto: apertura diretta scheda prodotto.
- Se il codice e' nuovo: precompilazione nuovo prodotto.
- Anagrafica prodotti: fornitore, categoria, unita', minimo, obiettivo,
  step, barcode, scadenza e posizione.
- Ordini raggruppati per fornitore, solo prodotti sotto soglia.
- Pulsante GENERA LISTA per ogni fornitore.
- Scadenze ordinate dalla piu' vicina.
- Storico delle variazioni di giacenza.
- Prelievo vocale TEST: riconosce frase e chiede conferma prima di scalare.
- Export Inventario_bar.xlsx in Download/GestionaleBar.
- Foglio Generale completo.
- Fogli fornitori con SOLO i prodotti da ordinare.

COME SI OTTIENE L'APK
---------------------
Il progetto contiene gia' il workflow .github/workflows/build-apk.yml.
Caricandolo in un repository GitHub e avviando la build, viene prodotto:

  app-debug.apk

che puo' essere installato direttamente sul telefono Android.
Non servono modifiche al codice.

TEST CONSIGLIATO
----------------
1. Aprire l'app e controllare i prodotti demo.
2. Scansionare un barcode demo o un prodotto registrato.
3. Aggiornare una giacenza e verificare OK/MANCANTE.
4. Fare una foto a un'etichetta e controllare il riconoscimento.
5. Provare un prelievo vocale, es. "due Coca Cola".
6. Aprire Ordini e generare una lista fornitore.
7. Premere ESPORTA EXCEL e controllare Download/GestionaleBar/Inventario_bar.xlsx.
8. Annotare tutto cio' che va cambiato, tolto o aggiunto.

NOTA
----
Questa e' volutamente una versione TEST separata dal MASTER.
I dati vengono salvati localmente dall'app sul telefono.
